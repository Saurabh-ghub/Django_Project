from django.db import models

# Create your models here.
class Bookshelf(models.Model):
    code =models.CharField(max_length=3)
    theme = models.CharField(max_length=64)
    def __str__(self):
        return f"{self.theme} ({self.code})"


class Book(models.Model):
    name = models.ForeignKey(Bookshelf, on_delete=models.CASCADE,related_name="book_type")
    cover = models.CharField(max_length=64,null=True)
   
    author = models.CharField(max_length=64,null=True)
    price = models.IntegerField(null=True)
    
    document =models.FileField(upload_to='media/')
    def  __str__(self):
        return f"{self.cover} -- {self.author}"
class Purchaser(models.Model):
    first = models.CharField(max_length=64)
    last = models.CharField(max_length=64)
    books = models.ManyToManyField(Book,blank=True,related_name="purchasers")

    def __str__(self):
        return f"{self.first}  {self.last}"

