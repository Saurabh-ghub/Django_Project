from django.shortcuts import render,redirect
from django.contrib import messages
from django.http import HttpResponse,Http404
from django.core.files.storage import FileSystemStorage
from .forms import BookForm
from .models import Book
from django.contrib.auth.models import User, auth
# Create your views here.

def login(request):
    if request.method=="POST":
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request, user)
            return redirect("index")
        else:
            messages.info(request,'invalid credentials')
            return redirect('login')
    else:
        return render(request,'login1.html')

def upload(request):
    if request.method=='POST':
        form =BookForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return HttpResponse('Succesfull')
    else:
        form = BookForm()
           
        return render(request,'upload.html',{
            'form':form
        })
       
        
        
        




def book(request,book_id):
    try:
        book=Book.objects.get(pk=book_id)
    except Book.DoesNotExists:
        raise Http404("Book does not exists")
    context ={
        "book":book,
        "purchasers":book.purchasers.all()
    }

    return render(request,"book.html",context)







def index(request):
    data = Book.objects.all()
    context = {
        "book": data
    }



    return render(request, "index.html",context)